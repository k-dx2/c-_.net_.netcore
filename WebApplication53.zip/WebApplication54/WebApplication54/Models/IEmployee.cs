﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication54.Models
{
    interface IEmployee
    {
        public List<Employee> AddEmp();
    }
}
